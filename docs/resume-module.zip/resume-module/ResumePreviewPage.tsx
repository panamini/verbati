import React from "react";
import { resumeLayoutSpec } from "./resume-layout.spec";
import type { ResumeData, ResumeLayoutVariantId } from "./resume.types";
import "./resume-preview.css";

type ResumePreviewPageProps = {
  data: ResumeData;
  mode?: "comparison" | ResumeLayoutVariantId;
};

function SidebarSection({
  title,
  children,
  variantId,
}: {
  title: string;
  children: React.ReactNode;
  variantId: ResumeLayoutVariantId;
}) {
  return (
    <section className={`sidebar-section sidebar-section--${variantId}`}>
      <h3 className={`sidebar-title sidebar-title--${variantId}`}>{title}</h3>
      <div className={`sidebar-content sidebar-content--${variantId}`}>{children}</div>
    </section>
  );
}

function MainSection({
  title,
  children,
  variantId,
}: {
  title: string;
  children: React.ReactNode;
  variantId: ResumeLayoutVariantId;
}) {
  return (
    <section className={`main-section main-section--${variantId}`}>
      <div className={`main-heading-row main-heading-row--${variantId}`}>
        <h2 className={`main-heading main-heading--${variantId}`}>{title}</h2>
        <div className={`main-heading-rule main-heading-rule--${variantId}`} />
      </div>
      {children}
    </section>
  );
}

function HeaderMeta({
  items,
  variantId,
}: {
  items: ResumeData["metadata"];
  variantId: ResumeLayoutVariantId;
}) {
  return (
    <dl className={`meta-grid meta-grid--${variantId}`} aria-label="Resume metadata">
      {items.map((item) => (
        <div key={item.label} className="meta-item">
          <dt>{item.label}</dt>
          <dd>{item.value}</dd>
        </div>
      ))}
    </dl>
  );
}

function ResumePage({
  variantId,
  data,
}: {
  variantId: ResumeLayoutVariantId;
  data: ResumeData;
}) {
  const variant = resumeLayoutSpec.variants[variantId];

  const pageVars = {
    "--page-width": resumeLayoutSpec.page.width,
    "--page-height": resumeLayoutSpec.page.height,
    "--page-radius": resumeLayoutSpec.page.borderRadius,
    "--margin-top": variant.margins.top,
    "--margin-right": variant.margins.right,
    "--margin-bottom": variant.margins.bottom,
    "--margin-left": variant.margins.left,
    "--sidebar-width": variant.columns.sidebar,
    "--gutter-width": variant.columns.gutter,
    "--main-width": variant.columns.main,
    "--header-row-gap": variant.header.rowGap,
    "--header-bottom-padding": variant.header.bottomPadding,
    "--header-summary-width": variant.header.summaryMaxWidth,
    "--header-title-margin-top": variant.header.titleMarginTop,
    "--body-row-gap": variant.body.rowGap,
    "--sidebar-right-padding": variant.body.sidebarRightPadding,
    "--main-left-padding": variant.body.mainLeftPadding,
    "--sidebar-section-gap": variant.sidebarSection.marginBottom,
    "--sidebar-title-margin": variant.sidebarSection.titleMarginBottom,
    "--sidebar-title-padding": variant.sidebarSection.titlePaddingBottom,
    "--sidebar-content-gap": variant.sidebarSection.contentGap,
    "--main-section-gap": variant.mainSection.marginBottom,
    "--main-heading-gap": variant.mainSection.headingGap,
    "--main-heading-margin": variant.mainSection.headingMarginBottom,
    "--experience-date-column": variant.experience.dateColumn,
    "--experience-column-gap": variant.experience.columnGap,
    "--experience-item-gap": variant.experience.itemGap,
    "--experience-org-margin": variant.experience.orgMarginBottom,
    "--experience-bullets-padding": variant.experience.bulletsPaddingLeft,
    "--experience-bullets-gap": variant.experience.bulletsGap,
    "--project-gap": variant.projects.cardGap,
    "--project-padding": variant.projects.cardPadding,
    "--education-gap": variant.education.itemGap,
    "--skill-gap": variant.skills.gap,
    "--skill-padding-inline": variant.skills.paddingInline,
    "--skill-padding-block": variant.skills.paddingBlock,
    "--display-size-adjust": variant.density.displaySizeAdjust,
    "--title-size-adjust": variant.density.titleSizeAdjust,
    "--body-size-adjust": variant.density.bodySizeAdjust,
    "--body-sm-size-adjust": variant.density.bodySmSizeAdjust,
    "--section-gap-adjust": variant.density.sectionGapAdjust,
    "--heading-margin-adjust": variant.density.headingMarginAdjust,
    "--bullet-gap-adjust": variant.density.bulletGapAdjust,
    "--project-gap-adjust": variant.density.projectGapAdjust,
    "--project-padding-adjust": variant.density.projectPaddingAdjust,
  } as React.CSSProperties;

  return (
    <article className={`resume-page resume-page--${variant.id}`} style={pageVars} aria-label={variant.label}>
      <div className="page-label">{variant.label}</div>

      <div className="resume-inner">
        <header className="resume-header">
          <div className="header-copy">
            <p className="eyebrow">Résumé</p>
            <h1 className="name">{data.name}</h1>
            <p className="title">{data.title}</p>
            <p className="summary">{data.summary}</p>
          </div>
          <HeaderMeta items={data.metadata} variantId={variant.id} />
        </header>

        <div className="resume-grid">
          <aside className="resume-sidebar">
            <SidebarSection title="Contact" variantId={variant.id}>
              <ul className="compact-list">
                {data.contact.map((item) => (
                  <li key={item.label}>
                    <span className="label">{item.label}</span>
                    <span className="value">{item.value}</span>
                  </li>
                ))}
              </ul>
            </SidebarSection>

            <SidebarSection title="Skills" variantId={variant.id}>
              <ul className="skills-list">
                {data.skills.map((skill) => (
                  <li key={skill}>{skill}</li>
                ))}
              </ul>
            </SidebarSection>

            <SidebarSection title="Languages" variantId={variant.id}>
              <ul className="compact-list compact-list--languages">
                {data.languages.map((language) => (
                  <li key={language.name}>
                    <span className="label">{language.name}</span>
                    <span className="value">{language.level}</span>
                  </li>
                ))}
              </ul>
            </SidebarSection>
          </aside>

          <div className="resume-divider" aria-hidden="true" />

          <main className="resume-main">
            <MainSection title="Experience" variantId={variant.id}>
              <div className="experience-stack">
                {data.experience.map((item) => (
                  <article key={`${item.company}-${item.role}`} className="experience-item">
                    <div className="experience-period">{item.period}</div>
                    <div>
                      <h3 className="entry-title">{item.role}</h3>
                      <p className="entry-subtitle">
                        {item.company} · {item.location}
                      </p>
                      <ul className="bullet-list">
                        {item.bullets.map((bullet) => (
                          <li key={bullet}>{bullet}</li>
                        ))}
                      </ul>
                    </div>
                  </article>
                ))}
              </div>
            </MainSection>

            <MainSection title="Selected projects" variantId={variant.id}>
              <div className="projects-grid">
                {data.projects.map((project) => (
                  <article className={`project-card project-card--${variant.id}`} key={project.name}>
                    <h3 className="entry-title">{project.name}</h3>
                    <p className="entry-subtitle entry-subtitle--project">{project.meta}</p>
                    <p className="project-copy">{project.description}</p>
                  </article>
                ))}
              </div>
            </MainSection>

            <MainSection title="Education" variantId={variant.id}>
              <div className="education-stack">
                {data.education.map((item) => (
                  <article key={`${item.school}-${item.degree}`} className="education-item">
                    <div>
                      <h3 className="entry-title">{item.degree}</h3>
                      <p className="entry-subtitle">{item.school}</p>
                    </div>
                    <p className="education-period">{item.period}</p>
                  </article>
                ))}
              </div>
            </MainSection>
          </main>
        </div>
      </div>
    </article>
  );
}

export default function ResumePreviewPage({
  data,
  mode = "comparison",
}: ResumePreviewPageProps) {
  const variantIds: ResumeLayoutVariantId[] =
    mode === "comparison" ? ["tschichold", "golden"] : [mode];

  return (
    <div className="resume-preview-shell">
      {mode === "comparison" && (
        <section className="resume-preview-intro">
          <div className="intro-panel">
            <p className="intro-kicker">A4 editorial résumé system</p>
            <h1 className="intro-title">Spec-faithful geometry with a more polished visual language.</h1>
            <p className="intro-copy">
              This revision keeps the stronger atmosphere of the draft while restoring the internal layout rules: a real three-column page grid, spec-based margins, a date column for experience, and two-card project treatment.
            </p>
          </div>
          <aside className="token-panel">
            <p className="token-kicker">What changed</p>
            <ul className="token-list">
              <li><strong>True page grid</strong><span>sidebar / gutter / main</span></li>
              <li><strong>Spec spacing</strong><span>mm values for margins, section gaps, and paddings</span></li>
              <li><strong>Content discipline</strong><span>20mm date column and card-based projects</span></li>
              <li><strong>Variant logic</strong><span>Model B stays softer without breaking the base system</span></li>
              <li><strong>Bench check</strong><span>Model A uses an exact 2:3:4:6 margin canon</span></li>
            </ul>
          </aside>
        </section>
      )}

      <div className="resume-preview-grid">
        {variantIds.map((variantId) => (
          <ResumePage key={variantId} variantId={variantId} data={data} />
        ))}
      </div>
    </div>
  );
}
