import type { ResumeLayoutVariantId } from "./resume.types";

export type ResumeDensitySpec = {
  displaySizeAdjust: string;
  titleSizeAdjust: string;
  bodySizeAdjust: string;
  bodySmSizeAdjust: string;
  sectionGapAdjust: string;
  headingMarginAdjust: string;
  bulletGapAdjust: string;
  projectGapAdjust: string;
  projectPaddingAdjust: string;
};

export type ResumeVariantSpec = {
  id: ResumeLayoutVariantId;
  label: string;
  title: string;
  subtitle: string;
  chips: string[];
  margins: { top: string; right: string; bottom: string; left: string };
  columns: { sidebar: string; gutter: string; main: string };
  liveArea: { width: string; height: string };
  header: {
    rowGap: string;
    bottomPadding: string;
    summaryMaxWidth: string;
    titleMarginTop: string;
  };
  body: { rowGap: string; sidebarRightPadding: string; mainLeftPadding: string };
  sidebarSection: {
    marginBottom: string;
    titleMarginBottom: string;
    titlePaddingBottom: string;
    contentGap: string;
  };
  mainSection: {
    marginBottom: string;
    headingGap: string;
    headingMarginBottom: string;
  };
  experience: {
    dateColumn: string;
    columnGap: string;
    itemGap: string;
    orgMarginBottom: string;
    bulletsPaddingLeft: string;
    bulletsGap: string;
  };
  projects: { cardGap: string; cardPadding: string; cardBackground: "surface" | "surfaceMuted" };
  education: { itemGap: string };
  skills: { gap: string; paddingInline: string; paddingBlock: string };
  density: ResumeDensitySpec;
};

export const resumeLayoutSpec = {
  page: {
    width: "210mm",
    height: "297mm",
    borderRadius: "8mm",
  },
  variants: {
    tschichold: {
      id: "tschichold",
      label: "Model A — Tschichold grid",
      title: "Tschichold grid",
      subtitle: "Strict 2:3:4:6 canon with a calmer editorial tone",
      chips: ["Editorial", "Structured", "Dense"],
      margins: { top: "26.25mm", right: "35mm", bottom: "52.5mm", left: "17.5mm" },
      columns: { sidebar: "42mm", gutter: "11mm", main: "104.5mm" },
      liveArea: { width: "157.5mm", height: "218.25mm" },
      header: { rowGap: "3mm", bottomPadding: "5mm", summaryMaxWidth: "120mm", titleMarginTop: "1mm" },
      body: { rowGap: "8mm", sidebarRightPadding: "2mm", mainLeftPadding: "5mm" },
      sidebarSection: { marginBottom: "6mm", titleMarginBottom: "2mm", titlePaddingBottom: "1.5mm", contentGap: "1.6mm" },
      mainSection: { marginBottom: "6mm", headingGap: "3mm", headingMarginBottom: "2.5mm" },
      experience: { dateColumn: "20mm", columnGap: "4mm", itemGap: "5mm", orgMarginBottom: "1.6mm", bulletsPaddingLeft: "4mm", bulletsGap: "1.2mm" },
      projects: { cardGap: "3.5mm", cardPadding: "3.2mm", cardBackground: "surface" },
      education: { itemGap: "1.8mm" },
      skills: { gap: "2mm", paddingInline: "2.6mm", paddingBlock: "1.2mm" },
      density: {
        displaySizeAdjust: "-0.45mm",
        titleSizeAdjust: "-0.14mm",
        bodySizeAdjust: "-0.12mm",
        bodySmSizeAdjust: "-0.12mm",
        sectionGapAdjust: "-1.15mm",
        headingMarginAdjust: "-0.45mm",
        bulletGapAdjust: "-0.22mm",
        projectGapAdjust: "-0.55mm",
        projectPaddingAdjust: "-0.35mm",
      },
    },
    golden: {
      id: "golden",
      label: "Model B — Golden-ratio tone",
      title: "Golden-ratio tone",
      subtitle: "Softer spacing and calmer visual weight",
      chips: ["Premium", "Open", "Balanced"],
      margins: { top: "21mm", right: "30mm", bottom: "34mm", left: "18mm" },
      columns: { sidebar: "38mm", gutter: "10mm", main: "114mm" },
      liveArea: { width: "162mm", height: "242mm" },
      header: { rowGap: "3mm", bottomPadding: "5mm", summaryMaxWidth: "120mm", titleMarginTop: "1mm" },
      body: { rowGap: "8mm", sidebarRightPadding: "2mm", mainLeftPadding: "5mm" },
      sidebarSection: { marginBottom: "6mm", titleMarginBottom: "2mm", titlePaddingBottom: "1.5mm", contentGap: "1.6mm" },
      mainSection: { marginBottom: "6mm", headingGap: "3mm", headingMarginBottom: "2.5mm" },
      experience: { dateColumn: "20mm", columnGap: "4mm", itemGap: "5mm", orgMarginBottom: "1.6mm", bulletsPaddingLeft: "4mm", bulletsGap: "1.2mm" },
      projects: { cardGap: "3.5mm", cardPadding: "3.2mm", cardBackground: "surfaceMuted" },
      education: { itemGap: "1.8mm" },
      skills: { gap: "2mm", paddingInline: "2.6mm", paddingBlock: "1.2mm" },
      density: {
        displaySizeAdjust: "0.25mm",
        titleSizeAdjust: "0mm",
        bodySizeAdjust: "0mm",
        bodySmSizeAdjust: "0mm",
        sectionGapAdjust: "0mm",
        headingMarginAdjust: "0mm",
        bulletGapAdjust: "0mm",
        projectGapAdjust: "0mm",
        projectPaddingAdjust: "0mm",
      },
    },
  } satisfies Record<ResumeLayoutVariantId, ResumeVariantSpec>,
} as const;
